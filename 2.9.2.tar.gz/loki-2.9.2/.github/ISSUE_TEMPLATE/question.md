---
name: Question
about: 'Questions can be submitted to our forum, mailing list or Slack'
title: ''
labels: ''
assignees: ''

---

You may submit questions in any of the following ways:
  - On our [community forum](https://community.grafana.com/c/grafana-loki/41)
  - To our [mailing list](https://groups.google.com/forum/#!forum/lokiproject)
  - In `#loki` in [Grafana's Public Slack](https://slack.grafana.com/)

**NOTE: All questions submitted as issues will be closed.**
