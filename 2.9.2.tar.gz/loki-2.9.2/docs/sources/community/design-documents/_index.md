---
title: Design documents
description: Loki Design documents
aliases: 
- ../design-documents/
weight: 600
---
# Design documents

- [Labels from Logs]({{< relref "./labels" >}})
- [Promtail Push API]({{< relref "./2020-02-Promtail-Push-API" >}})
- [Write-Ahead Logs]({{< relref "./2020-09-Write-Ahead-Log" >}})
- [Ordering Constraint Removal]({{< relref "./2021-01-Ordering-Constraint-Removal" >}})
