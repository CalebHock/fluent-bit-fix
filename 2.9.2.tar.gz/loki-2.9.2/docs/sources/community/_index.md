---
title: Community
description: Community
weight: 1100
---
# Community

1. [Governance]({{< relref "./governance" >}})
1. [Getting in Touch]({{< relref "./getting-in-touch" >}})
1. [Contributing]({{< relref "./contributing" >}})
1. [Maintaining Loki]({{< relref "./maintaining" >}})
1. [Loki Improvement Documents]({{< relref "./lids" >}})
1. [Design documents]({{< relref "./design-documents" >}})
