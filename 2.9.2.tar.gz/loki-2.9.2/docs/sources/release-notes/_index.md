---
title: Release notes
description: Release notes
weight: 100
---
# Release notes

Release notes for Loki are in the CHANGELOG for the release and
listed here by version number.

- [V2.9 release notes]({{< relref "./v2-9" >}})
- [V2.8 release notes]({{< relref "./v2-8" >}})
- [V2.7 release notes]({{< relref "./v2-7" >}})
- [V2.6 release notes]({{< relref "./v2-6" >}})
- [V2.5 release notes]({{< relref "./v2-5" >}})
- [V2.4 release notes]({{< relref "./v2-4" >}})
- [V2.3 release notes]({{< relref "./v2-3" >}})

The details about our release cadence are documented [here]({{< relref "./cadence" >}}).
