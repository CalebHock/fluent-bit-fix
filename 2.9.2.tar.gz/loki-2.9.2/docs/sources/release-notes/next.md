---
title: V?.?
description: Version ?.? release notes
weight: 10000
draft: true
---

# V?.?
Grafana Labs is excited to announce the release of Loki ?.?.? Here's a summary of new enhancements and important fixes:

:warning: This a placeholder for the next release. Clean up all features listed below

## Features and enhancements

## Upgrade Considerations

## Bug fixes
