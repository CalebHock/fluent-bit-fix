---
title: Operations
description: Operations
weight: 900
---

# Operations

This section covers operational topics in Loki:

{{< section >}}

- [Upgrade Loki]({{< relref "../setup/upgrade" >}})
