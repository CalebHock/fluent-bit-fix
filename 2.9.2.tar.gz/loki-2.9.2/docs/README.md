# Loki Documentation

<p align="center"> <img src="sources/logo_and_name.png" alt="Loki Logo"> <br>
  <small>Like Prometheus, but for logs!</small> </p>
  
Please see the [Documentation Site](https://grafana.com/docs/loki/latest/) The files in this directory are used to generate it but consequently the links don't work in Github.

To contribute to these docs, refer to the `Documentation` section in [CONTRIBUTING.md](../CONTRIBUTING.md).